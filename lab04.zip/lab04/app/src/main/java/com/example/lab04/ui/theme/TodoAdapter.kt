package com.example.todoapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView

class TodoAdapter(
    private val todoList: MutableList<TodoItem>
) : RecyclerView.Adapter<TodoAdapter.TodoViewHolder>() {

    inner class TodoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val todoText: TextView = itemView.findViewById(R.id.todoText)
        val editButton: ImageView = itemView.findViewById(R.id.btnEdit)
        val deleteButton: ImageView = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TodoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_todo, parent, false)
        return TodoViewHolder(view)
    }

    override fun onBindViewHolder(holder: TodoViewHolder, position: Int) {
        val todoItem = todoList[position]
        holder.todoText.text = todoItem.title

        // Edit Todo
        holder.editButton.setOnClickListener {
            val context = holder.itemView.context
            val editText = EditText(context)
            editText.setText(todoItem.title)

            AlertDialog.Builder(context)
                .setTitle("Edit Todo")
                .setView(editText)
                .setPositiveButton("Update") { _, _ ->
                    todoItem.title = editText.text.toString()
                    notifyItemChanged(position)
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Delete Todo
        holder.deleteButton.setOnClickListener {
            todoList.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, todoList.size)
        }
    }

    override fun getItemCount(): Int = todoList.size
}
