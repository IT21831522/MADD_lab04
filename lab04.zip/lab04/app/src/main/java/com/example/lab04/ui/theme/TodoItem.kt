package com.example.todoapp

data class TodoItem(
    var id: Int,
    var title: String
)
