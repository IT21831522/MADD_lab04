package com.example.todoapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        val todoList: MutableList<TodoItem> = mutableListOf()
        var idCounter = 1
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editTodo: EditText = findViewById(R.id.editTodo)
        val btnAdd: Button = findViewById(R.id.btnAdd)
        val btnViewTodos: Button = findViewById(R.id.btnViewTodos)

        btnAdd.setOnClickListener {
            val todoText = editTodo.text.toString()
            if (todoText.isNotEmpty()) {
                todoList.add(TodoItem(idCounter++, todoText))
                Toast.makeText(this, "Todo Added!", Toast.LENGTH_SHORT).show()
                editTodo.text.clear()
            } else {
                Toast.makeText(this, "Please enter a todo", Toast.LENGTH_SHORT).show()
            }
        }

        btnViewTodos.setOnClickListener {
            val intent = Intent(this, TodoListActivity::class.java)
            startActivity(intent)
        }
    }
}
